import { config } from 'dotenv';
config();

import '@/ai/flows/generate-yusra-insight.ts';