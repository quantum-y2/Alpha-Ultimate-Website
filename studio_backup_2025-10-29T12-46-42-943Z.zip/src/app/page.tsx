'use client';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { useState, useEffect } from 'react';

export default function Home() {
    const [isClient, setIsClient] = useState(false);

    useEffect(() => {
        setIsClient(true);
    }, []);

    return (
        <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
                <div className="relative h-screen w-full overflow-hidden">
                    {isClient && (
                         <video
                            src="https://videos.pexels.com/video-files/3253412/3253412-hd_1920_1080_25fps.mp4"
                            autoPlay
                            loop
                            muted
                            playsInline
                            className="absolute top-0 left-0 w-full h-full object-cover z-[-1]"
                        />
                    )}
                    <div className="absolute inset-0 bg-black/70" />
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center text-white p-4">
                            <h1 className="font-headline text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-accent">
                                Alpha Ultimate Ltd.
                            </h1>
                            <p className="mt-4 text-xl md:text-2xl text-muted-foreground">
                                Beyond the every limit...
                            </p>
                            <Link href="/services">
                                <Button size="lg" className="mt-8 neon-button text-lg">
                                    Explore Our Services
                                </Button>
                            </Link>
                        </div>
                    </div>
                </div>
            </main>
            <Footer />
        </div>
    );
}
