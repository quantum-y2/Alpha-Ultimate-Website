import { redirect } from 'next/navigation';

export default function PortalRootPage() {
  redirect('/portal/login');
}
